using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class ProjectsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
