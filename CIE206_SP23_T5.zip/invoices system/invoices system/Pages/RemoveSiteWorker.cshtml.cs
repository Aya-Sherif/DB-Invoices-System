using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class RemoveSiteWorkerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
