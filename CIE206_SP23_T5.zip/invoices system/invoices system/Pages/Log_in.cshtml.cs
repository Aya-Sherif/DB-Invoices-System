using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class Log_inModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
