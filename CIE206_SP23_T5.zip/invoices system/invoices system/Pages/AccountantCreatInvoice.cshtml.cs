using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class AccountantCreatInvoiceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
