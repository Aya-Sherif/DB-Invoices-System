﻿namespace invoices_system.Models
{
    public class Weekly_Cost
    {

        public string invoiceID { get; set; }
        public int Total { get; set; }
        public int SarfElta3lya { get; set; }
        public int Loan { get; set; }
        public int Deduction { get; set; }
        public string weeklyCostDate { get; set; }




    }
}
