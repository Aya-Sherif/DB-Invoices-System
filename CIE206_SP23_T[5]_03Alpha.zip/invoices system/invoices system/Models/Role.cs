﻿namespace invoices_system.Models
{
    public class Role
    {
        public string roleID { get; set; }
        public string roleName { get; set; }
        
    }
}
