﻿namespace invoices_system.Models
{
    public class Invoice
    {

        public string contractorName { get; set; }
        public string projectID { get; set; }
        public string startDate { get; set; }

        public string endDate { get; set; }
        public string invoiceType { get; set; }
        public string invoiceID { get; set; }
        public int total { get; set; }

        public string Elta3lya { get; set; }

        public string invoiceStatus { get; set; }





    }
}