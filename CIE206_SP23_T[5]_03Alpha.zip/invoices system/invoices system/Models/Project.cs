﻿namespace invoices_system.Models
{
    public class Project
    {
       
        public string projectName { get; set; }
        public string projectID { get; set; }

        public string startDate { get; set; }

        public string endDate { get; set; }


       
    }
}
