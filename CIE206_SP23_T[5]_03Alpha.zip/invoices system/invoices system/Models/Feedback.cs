﻿namespace invoices_system.Models
{
    public class Feedback
    {

        public string feedbackDate { get; set; }
        public string invoiceID { get; set;}
    }
}
