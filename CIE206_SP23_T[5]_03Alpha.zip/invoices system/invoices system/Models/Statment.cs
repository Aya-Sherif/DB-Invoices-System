﻿namespace invoices_system.Models
{
    public class Statment
    {

        public string Statements { get; set; }
        public string Unit { get; set; }
        public int previousQuantities { get; set; }
        public int currentQuantities { get; set; }
        public int Total { get; set; }
        public int categoryValue { get; set; }
        public int currentValue { get; set; }
        public int totalQuantities { get; set; }
        public string invoiceID { get; set; }



    }
}
