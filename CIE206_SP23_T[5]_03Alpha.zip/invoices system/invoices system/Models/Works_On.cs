﻿namespace invoices_system.Models
{
    public class Works_On
    {
        public int projectID { get; set; }
        public int workerID { get; set; }

    }
}
