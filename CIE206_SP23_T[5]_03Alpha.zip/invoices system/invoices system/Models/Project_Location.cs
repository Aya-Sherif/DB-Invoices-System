﻿namespace invoices_system.Models
{
    public class Project_Location
    {
        public string projectID { get; set; }
        public string projectLocation { get; set; }

    }
}
