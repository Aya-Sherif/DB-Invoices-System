﻿namespace invoices_system.Models
{
    public class Worker
    {

        public string workerName { get; set; }
        public string workerID { get; set; }
        public string phoneNumber { get; set; }
        public string userName { get; set; }
        public string workerPassword { get; set; }
        public string roleID { get; set; }

    }
}
