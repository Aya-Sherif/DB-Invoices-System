﻿namespace invoices_system.Models
{
    public class Privileges
    {
        public string roleID { get; set; }
        public string privilegesID { get; set; }

    }
}
