using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class CommentOfInvoicesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
