using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class MainProjectAdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
