using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace invoices_system.Pages
{
    public class AccountantEditInvoiceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
